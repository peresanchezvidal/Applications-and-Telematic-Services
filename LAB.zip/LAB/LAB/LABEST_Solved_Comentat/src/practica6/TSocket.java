package practica6;

import java.util.Iterator;
import practica1.CircularQ.CircularQueue;
import practica4.Protocol;
import util.Const;
import util.TCPSegment;
import util.TSocket_base;

public class TSocket extends TSocket_base {

    protected int MSS;
    protected int snd_sndNxt;              // seqüència següent segment a enviar
    protected int snd_rcvNxt;              // seqüència següent que espera rebre el peer
    protected int snd_rcvWnd;              // finestra del peer (0 → zero-window)
    protected int snd_cngWnd;              // congestion window
    protected int snd_minWnd;              // mínim(snd_rcvWnd, snd_cngWnd)
    protected CircularQueue<TCPSegment> snd_unacknowledged_segs;
    protected boolean zero_wnd_probe_ON;

    protected int rcv_rcvNxt;              // seqüència següent que esperem
    protected CircularQueue<TCPSegment> rcv_Queue;
    protected int rcv_SegConsumedBytes;

    protected TSocket(Protocol p, int localPort, int remotePort) {
        super(p.getNetwork());
        this.localPort  = localPort;
        this.remotePort = remotePort;
        p.addActiveTSocket(this);

        // ---- inicialització sender ----
        this.MSS         = p.getNetwork().getMTU() - Const.IP_HEADER - Const.TCP_HEADER;
        this.MSS         = Math.min(this.MSS, 10);  // per a la pràctica
        this.snd_rcvWnd  = Const.RCV_QUEUE_SIZE;
        this.snd_cngWnd  = 3;
        this.snd_minWnd  = Math.min(this.snd_rcvWnd, this.snd_cngWnd);
        this.snd_sndNxt  = 0;
        this.snd_rcvNxt  = 0;
        this.zero_wnd_probe_ON = false;
        this.snd_unacknowledged_segs = new CircularQueue<>(this.snd_cngWnd);

        // ---- inicialització receiver ----
        this.rcv_Queue           = new CircularQueue<>(Const.RCV_QUEUE_SIZE);
        this.rcv_SegConsumedBytes = 0;
        this.rcv_rcvNxt          = 0;
    }

    @Override
    public void sendData(byte[] data, int offset, int length) {
        lock.lock();
        try {
            int enviats = 0;
            while (enviats < length) {
                // espera fins que hi hagi finestra lliure
                while (snd_sndNxt - snd_rcvNxt >= snd_minWnd) {
                    appCV.awaitUninterruptibly();
                }

                int chunk;
                TCPSegment seg;

                if (snd_rcvWnd > 0) {
                    // enviament normal
                    chunk = Math.min(length - enviats, MSS);
                    seg   = segmentize(data, offset + enviats, chunk);
                } else {
                    // zero-window probe: 1 byte a veure si s'obre la finestra
                    chunk = 1;
                    seg   = segmentize(data, offset + enviats, chunk);
                    zero_wnd_probe_ON = true;
                    log.printPURPLE("----- zero-window probe ON -----");
                }

                // enviem sempre el segment
                network.send(seg);

                // si no hi havia RTO, l'arranquem
                if (snd_unacknowledged_segs.empty()) {
                    startRTO(seg);
                }
                snd_unacknowledged_segs.put(seg);
                ++snd_sndNxt;
                enviats += chunk;
            }
        } finally {
            lock.unlock();
        }
    }

    protected TCPSegment segmentize(byte[] data, int offset, int length) {
        TCPSegment seg = new TCPSegment();
        seg.setPsh(true);
        seg.setSourcePort(localPort);
        seg.setDestinationPort(remotePort);
        seg.setSeqNum(snd_sndNxt);
        seg.setData(data, offset, length);
        return seg;
    }

    @Override
    protected void timeout(TCPSegment timeoutSeg) {
        lock.lock();
        try {
            if (!snd_unacknowledged_segs.empty()) {
                // Retransmetem tots els pendents
                for (TCPSegment seg : snd_unacknowledged_segs) {
                    if (zero_wnd_probe_ON) {
                        log.printPURPLE("0-wnd probe: " + seg);
                    } else {
                        log.printPURPLE("retrans: " + seg);
                    }
                    network.send(seg);
                }
                // Programem nou RTO sobre el primer pendent
                TCPSegment next = snd_unacknowledged_segs.peekFirst();
                startRTO(next);
            }
        } finally {
            lock.unlock();
        }
    }

    @Override
    public int receiveData(byte[] buf, int offset, int maxlen) {
        lock.lock();
        try {
            while (rcv_Queue.empty()) {
                appCV.awaitUninterruptibly();
            }
            int total = 0;
            while (total < maxlen && !rcv_Queue.empty()) {
                total += consumeSegment(buf, offset + total, maxlen - total);
            }
            return total;
        } finally {
            lock.unlock();
        }
    }

    protected int consumeSegment(byte[] buf, int offset, int length) {
        TCPSegment seg = rcv_Queue.peekFirst();
        int toCopy = Math.min(length, seg.getDataLength() - rcv_SegConsumedBytes);
        System.arraycopy(seg.getData(), rcv_SegConsumedBytes, buf, offset, toCopy);
        rcv_SegConsumedBytes += toCopy;
        if (rcv_SegConsumedBytes == seg.getDataLength()) {
            rcv_Queue.get();
            rcv_SegConsumedBytes = 0;
        }
        return toCopy;
    }

    protected void sendAck() {
        TCPSegment ack = new TCPSegment();
        ack.setAck(true);
        ack.setSourcePort(localPort);
        ack.setDestinationPort(remotePort);
        ack.setAckNum(rcv_rcvNxt);
        ack.setWnd(rcv_Queue.free());
        network.send(ack);
    }

    @Override
    public void processReceivedSegment(TCPSegment rseg) {
        lock.lock();
        try {
            printRcvSeg(rseg);

            // --- Processament d'ACKs ---
            if (rseg.isAck() && rseg.getAckNum() > snd_rcvNxt) {
                Iterator<TCPSegment> it = snd_unacknowledged_segs.iterator();
                while (it.hasNext()) {
                    TCPSegment seg = it.next();
                    if (seg.getSeqNum() < rseg.getAckNum()) {
                        it.remove();
                    }
                }
                // si encara queden pendents, programem RTO sobre el primer
                if (!snd_unacknowledged_segs.empty()) {
                    startRTO(snd_unacknowledged_segs.peekFirst());
                }
                // si s'acaba la zero-window probe, la desactivem
                if (zero_wnd_probe_ON) {
                    zero_wnd_probe_ON = false;
                    log.printPURPLE("----- zero-window probe OFF -----");
                }
                snd_rcvNxt = rseg.getAckNum();
                snd_rcvWnd = rseg.getWnd();
                snd_minWnd = Math.max(1, Math.min(snd_rcvWnd, snd_cngWnd));
                appCV.signalAll();
            }
            // --- Processament de dades (PSH) ---
            else if (rseg.isPsh()) {
                if (rcv_Queue.full() && rseg.getSeqNum() == rcv_rcvNxt) {
                    log.printRED("\t\t ********** FLOW LOST: " + rseg + " **********\n");
                    return;
                }
                if (rseg.getSeqNum() == rcv_rcvNxt) {
                    rcv_Queue.put(rseg);
                    ++rcv_rcvNxt;
                    appCV.signalAll();
                }
                sendAck();
            }
        } finally {
            lock.unlock();
        }
    }

    @SuppressWarnings("unused")
    private void unacknowledgedSegments_content() {
        log.printBLACK("\n-------------- content begins  --------------");
        for (TCPSegment seg : snd_unacknowledged_segs) {
            log.printBLACK(seg.toString());
        }
        log.printBLACK("-------------- content ends    --------------\n");
    }
}
