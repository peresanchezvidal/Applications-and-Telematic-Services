//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica2.P0CZ;

public class TestSum {
    public TestSum() {
    }

    public static void main(String[] args) throws InterruptedException {
        CounterThread f1 = new CounterThread();
        CounterThread f2 = new CounterThread();
        f1.start();
        f2.start();
        f1.join();
        f2.join();
        System.out.println("x:" + CounterThread.x);
    }
}

//package practica2.P0CZ;
//
//public class TestSum {
//
//    public static void main(String[] args) throws InterruptedException {
//        throw new RuntimeException("//Completar...");
//    }
//}
