//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica2.P0CZ.Monitor;

public class TestSumCZ {
    public TestSumCZ() {
    }

    public static void main(String[] args) throws InterruptedException {
        MonitorCZ mon = new MonitorCZ();
        CounterThreadCZ f1 = new CounterThreadCZ(mon);
        CounterThreadCZ f2 = new CounterThreadCZ(mon);
        f1.start();
        f2.start();
        f1.join();
        f2.join();
        System.out.println("x:" + mon.getX());
    }
}
//package practica2.P0CZ.Monitor;
//
//public class TestSumCZ {
//
//    public static void main(String[] args) throws InterruptedException {
//        throw new RuntimeException("//Completar...");
//    }
//}
