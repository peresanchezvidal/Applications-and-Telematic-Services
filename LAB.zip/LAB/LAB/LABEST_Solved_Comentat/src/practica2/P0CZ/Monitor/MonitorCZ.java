package practica2.P0CZ.Monitor;

import java.util.concurrent.locks.ReentrantLock;

public class MonitorCZ {
    private int x = 0;
    ReentrantLock lock = new ReentrantLock();

    public MonitorCZ() {
    }

    public void inc() {
        this.lock.lock();

        try {
            ++this.x;
        } finally {
            this.lock.unlock();
        }

    }

    public int getX() {
        this.lock.lock();

        int var1;
        try {
            var1 = this.x;
        } finally {
            this.lock.unlock();
        }

        return var1;
    }
}

//package practica2.P0CZ.Monitor;
//
//import java.util.concurrent.locks.ReentrantLock;
//
//public class MonitorCZ {
//
//    private int x = 0;
//    //Completar...
//
//    public void inc() {
//        //Incrementa en una unitat el valor d'x
//        throw new RuntimeException("//Completar...");
//    }
//
//    public int getX() {
//        //Ha de retornar el valor d'x
//        throw new RuntimeException("//Completar...");
//    }
//
//}
