//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica2.Protocol;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import practica1.CircularQ.CircularQueue;
import util.SimNet;
import util.TCPSegment;

public class SimNet_Monitor implements SimNet {
    protected CircularQueue<TCPSegment> queue = new CircularQueue(100);
    protected ReentrantLock lock = new ReentrantLock();
    protected Condition putCnd;
    protected Condition getCnd;

    public SimNet_Monitor() {
        this.putCnd = this.lock.newCondition();
        this.getCnd = this.lock.newCondition();
    }

    @Override
    public void send(TCPSegment seg) {
        this.lock.lock();

        try {
            while(this.queue.full()) {
                this.putCnd.awaitUninterruptibly();
            }

            this.queue.put(seg);
            this.getCnd.signal();
        } finally {
            this.lock.unlock();
        }

    }

    public TCPSegment receive() {
        this.lock.lock();

        TCPSegment tmp;
        try {
            while(this.queue.empty()) {
                this.getCnd.awaitUninterruptibly();
            }

            this.putCnd.signal();
            tmp = (TCPSegment)this.queue.get();
        } finally {
            this.lock.unlock();
        }

        return tmp;
    }

    public int getMTU() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

//package practica2.Protocol;
//
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.ReentrantLock;
//import practica1.CircularQ.CircularQueue;
//import util.Const;
//import util.TCPSegment;
//import util.SimNet;
//
//public class SimNet_Monitor implements SimNet {
//
//  protected CircularQueue<TCPSegment> queue;
//  //Completar
//
//  public SimNet_Monitor() {
//    queue  = new CircularQueue<>(Const.SIMNET_QUEUE_SIZE);
//    //Completar
//  }
//
//  @Override
//  public void send(TCPSegment seg) {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public TCPSegment receive() {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public int getMTU() {
//    throw new UnsupportedOperationException("Not supported yet. NO cal completar fins a la pràctica 3...");
//  }
//
//}
