//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica2.P1Sync.Monitor;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class MonitorSync {
    private final int N;
    private int turnId = 0;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition turn;

    public MonitorSync(int N) {
        this.turn = this.lock.newCondition();
        this.N = N;
    }

    public void waitForTurn(int id) {
        this.lock.lock();

        try {
            while(this.turnId != id) {
                this.turn.awaitUninterruptibly();
            }
        } finally {
            this.lock.unlock();
        }

    }

    public void transferTurn() {
        this.lock.lock();

        try {
            this.turnId = (this.turnId + 1) % this.N;
            this.turn.signalAll();
        } finally {
            this.lock.unlock();
        }

    }
}

//package practica2.P1Sync.Monitor;
//
//import java.util.concurrent.locks.Condition;
//import java.util.concurrent.locks.ReentrantLock;
//
//public class MonitorSync {
//
//    private final int N;
//    
//    //Completar...
//
//    public MonitorSync(int N) {
//        this.N = N;
//    }
//
//    public void waitForTurn(int id) {
//        throw new RuntimeException("//Completar...");
//    }
//
//    public void transferTurn() {
//        throw new RuntimeException("//Completar...");
//    }
//}
