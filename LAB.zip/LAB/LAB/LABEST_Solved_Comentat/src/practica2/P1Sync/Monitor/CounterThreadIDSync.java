//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica2.P1Sync.Monitor;

public class CounterThreadIDSync extends Thread {
    private final MonitorSync mon;
    private final int id;

    public CounterThreadIDSync(MonitorSync mon, int id) {
        this.mon = mon;
        this.id = id;
    }

    @Override
    public void run() {
        for(int i = 0; i < 10; ++i) {
            this.mon.waitForTurn(this.id);
            System.out.print(this.id);
            this.mon.transferTurn();
        }

    }
}

//package practica2.P1Sync.Monitor;
//
//public class CounterThreadIDSync extends Thread {
//
//    private final MonitorSync mon;
//    private final int id;
//
//    public CounterThreadIDSync(MonitorSync mon, int id) {
//        this.mon = mon;
//        this.id = id;
//    }
//
//    @Override
//    public void run() {
//        for (int i = 0; i < 10; i++) {
//            throw new RuntimeException("//Completar...");
//        }
//    }
//
//}
