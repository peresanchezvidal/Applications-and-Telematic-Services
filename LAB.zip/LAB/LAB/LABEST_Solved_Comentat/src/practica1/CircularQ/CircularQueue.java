package practica1.CircularQ;

import java.util.Iterator;
import util.Queue;

public class CircularQueue<E> implements Queue<E> {
    /**
     * Array de tipus genèric (per cues).
     */
    private final E[] queue;
    
    /**
     * Dimensió de la cua circular. 
     */
    private final int N;
    
    /**
     * Número d'elements que hi ha a la cua.
     */
    private int numElem;
    
    /**
     * Primer element de la cua. 
     */
    private int head;
    
    /**
     * Primer lloc buit de la cua. 
     */
    private int tail;

    /**
     * Mètode constructor on es determina la dimensió de la cua. 
     * @param N dimensió de la cua
     */
    public CircularQueue(int N) {
        this.N = N;
        this.queue = (E[]) new Object[N];
    }

    /**
     * Mètode per saber quants elements té la cua. 
     * @return el numero d'elements que té al cua
     */
    public int size() {
        return this.numElem;
    }

    /**
     * Mètode per saber quants elements podem posar-hi a la cua.
     * @return Número d'espais lliures de la cua
     */
    public int free() {
        return this.N - this.numElem;
    }

    /**
     * Mètode per saber si la cua està buida.
     * @return torna true quan no hi ha elements a la cua. 
     */
    public boolean empty() {
        return this.numElem == 0;
    }

    /**
     * Mètoode per saber si la cua està plena
     * @return true si la cua està plena
     */
    public boolean full() {
        return this.numElem == this.N;
    }

    /**
     * Mètode que toena el primer element de la cua. !!No es borra, nomès ho saps. 
     * @return primer element de la cua
     * @throws IllegalStateException si la cua està buida.
     */
    public E peekFirst() {
        if (this.numElem == 0) {
            throw new IllegalStateException("Empty queue.");
        } else {
            return this.queue[this.head];
        }
    }

    /**
     * Mètode que extreu el primer element de la cua. L'agafa de la posició
     * head, i actualitza la variable head i numero d'elements.
     * @return primer element de la cua
     * @throws IllegalStateException si la cua està buida. 
     */
    public E get() {
        if (this.numElem == 0) {
            throw new IllegalStateException("Empty queue.");
        } else {
            E e = this.queue[this.head];
            this.head = (this.head + 1) % this.N;
            --this.numElem;
            return e;
        }
    }

    /**
     * Mètode que posa un nou element a la cua. El situa a la posició tail i acutalitza
     * tant la varible tail, ja que s'ha de desplaçar un endevant com el número d'elements
     * de la cua.
     * @param e Element que volem afegir a la cua
     * @throws IllegalStateException si la cua està plena
     */
    public void put(E e) {
        if (this.numElem == this.N) {
            throw new IllegalStateException("Full queue.");
        } else {
            this.queue[this.tail] = e;
            this.tail = (this.tail + 1) % this.N;
            ++this.numElem;
        }
    }

    /**
     * Mètode per imprimir tota la informació de la cua. 
     * @return String amb la informació de la cua.
     */
    public String toString() {
        if (this.numElem == 0) {
            return "[]";
        } else {
            String str = "[";

            for(int i = 0; i < this.numElem - 1; ++i) {
                str = str + this.queue[(this.head + i) % this.N] + ", ";
            }

            str = str + this.queue[(this.head + this.numElem - 1) % this.N] + "]";
            return str;
        }
    }

    /**
     * Crea un mètode iterador a la cua. 
     * @return 
     */
    @Override
    public Iterator<E> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator {
        /**
         * Index per on anirà el iterador
         */
        int index = 0;

        MyIterator() {
        }

        /**
         * Mètode que et diu si estàs o no a l'últim element de la cua. 
         * @return true si té algun altre element posteriorment. 
         */
        @Override
        public boolean hasNext() {
            return this.index < CircularQueue.this.numElem;
        }

        @Override
        public E next() {
            if (this.index == CircularQueue.this.numElem) {
                throw new IllegalStateException("There is no next element.");
            } else {
                E tmp = CircularQueue.this.queue[(CircularQueue.this.head + this.index) % CircularQueue.this.N];
                ++this.index;
                return tmp;
            }
        }

        @Override
        public void remove() {
            if (this.index < 1) {
                throw new IllegalStateException("Cannot remove element.");
            } else {
                --this.index;

                for(int i = this.index; i < CircularQueue.this.numElem; ++i) {
                    CircularQueue.this.queue[(CircularQueue.this.head + i) % CircularQueue.this.N] = CircularQueue.this.queue[(CircularQueue.this.head + 1 + i) % CircularQueue.this.N];
                }

                CircularQueue.this.tail = (CircularQueue.this.tail + CircularQueue.this.N - 1) % CircularQueue.this.N;
                CircularQueue.this.numElem--;
            }
        }
    }
}

//package practica1.CircularQ;
//
//import java.util.Iterator;
//import util.Queue;
//
//public class CircularQueue<E> implements Queue<E> {
//
//    private final E[] queue;
//    private final int N;
//    //Completar...
//
//    public CircularQueue(int N) {
//        this.N = N;
//        queue = (E[]) (new Object[N]);
//    }
//
//    @Override
//    public int size() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public int free() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public boolean empty() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public boolean full() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public E peekFirst() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public E get() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public void put(E e) {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public String toString() {
//        throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public Iterator<E> iterator() {
//        return new MyIterator();
//    }
//
//    class MyIterator implements Iterator {
//
//        //Completar...
//
//        @Override
//        public boolean hasNext() {
//            throw new RuntimeException("//Completar...");
//        }
//
//        @Override
//        public E next() {
//            throw new RuntimeException("//Completar...");
//        }
//
//        @Override
//        public void remove() {
//            throw new RuntimeException("//Completar...");
//        }
//
//    }
//}
