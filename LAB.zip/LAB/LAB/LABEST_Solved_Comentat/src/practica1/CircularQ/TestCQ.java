
package practica1.CircularQ;

import java.io.IOException;
import java.util.Arrays;

public class TestCQ {

    public static void main(String[] args) {
        CircularQueue<Integer> q = new CircularQueue<>(5);

        System.out.println("Començarem agafant una tot i que la cua està buida");

        try {
            q.get();
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Omplim");
        try {
            for (int i = 0; i < 5; i++) {
                System.out.println(q.toString());
                q.put(i + 1);
                
            }
            
            System.out.println(q.toString() + "Posarem un element extra que no hi cap");
            
            q.put(450);
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }

        System.out.println(q.toString() + "Agafarem les tres primeres");
        //q.put(i);
        try {
            q.get();
            System.out.println(q.toString());

            q.get();
            System.out.println(q.toString());

            q.get();
            System.out.println(q.toString());
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }
        
        System.out.println ("Afegirem fins que no hi càpiguen més");
        
        try {
            for (int i = 0; i <= 5; i++) {
                
                q.put(i + 93);
                System.out.println(q.toString());
            }
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
        }
    }
    
}

