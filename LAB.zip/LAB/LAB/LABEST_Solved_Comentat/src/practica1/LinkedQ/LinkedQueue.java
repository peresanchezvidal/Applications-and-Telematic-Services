//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica1.LinkedQ;

import java.util.Iterator;
import util.Queue;

public class LinkedQueue<E> implements Queue<E> {
    Node<E> head;
    Node<E> tail;
    int numElem;

    public LinkedQueue() {
    }

    @Override
    public int size() {
        return this.numElem;
    }

    @Override
    public int free() {
        throw new UnsupportedOperationException();
    }

    @Override
    public boolean empty() {
        return this.numElem == 0;
    }

    @Override
    public boolean full() {
        return false;
    }

    @Override
    public E peekFirst() {
        if (this.numElem == 0) {
            throw new IllegalStateException("Empty queue.");
        } else {
            return this.head.getValue();
        }
    }

    @Override
    public E get() {
        if (this.numElem == 0) {
            throw new IllegalStateException("Empty queue.");
        } else {
            E e = this.head.getValue();
            this.head = this.head.getNext();
            --this.numElem;
            if (this.numElem == 0) {
                this.tail = null;
            }

            return e;
        }
    }

    @Override
    public void put(E e) {
        Node<E> node = new Node();
        node.setValue(e);
        if (this.numElem == 0) {
            this.head = node;
        } else {
            this.tail.setNext(node);
        }

        this.tail = node;
        ++this.numElem;
    }

    @Override
    public String toString() {
        if (this.numElem == 0) {
            return "[]";
        } else {
            Node<E> act = this.head;
            String str = "[";

            for(int i = 0; i < this.numElem - 1; ++i) {
                str = str + act.getValue() + ", ";
                act = act.getNext();
            }

            str = str + this.tail.getValue() + "]";
            return str;
        }
    }

    @Override
    public Iterator<E> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator {
        Node<E> previous_1 = null;
        Node<E> previous_2 = null;
        Node<E> node;

        MyIterator() {
            this.node = LinkedQueue.this.head;
        }

        @Override
        public boolean hasNext() {
            return this.node != null;
        }

        @Override
        public E next() {
            if (this.node == null) {
                throw new IllegalStateException("There is no next element.");
            } else {
                E tmp = this.node.getValue();
                this.previous_2 = this.previous_1;
                this.previous_1 = this.node;
                this.node = this.node.getNext();
                return tmp;
            }
        }

        @Override
        public void remove() {
            if (this.previous_1 == this.previous_2) {
                throw new IllegalStateException("Cannot remove element.");
            } else {
                if (this.previous_2 == null) {
                    LinkedQueue.this.head = this.node;
                } else {
                    this.previous_2.setNext(this.node);
                }

                this.previous_1 = this.previous_2;
                --LinkedQueue.this.numElem;
                if (LinkedQueue.this.numElem == 0 || this.node == null) {
                    LinkedQueue.this.tail = this.previous_1;
                }

            }
        }
    }
}

//package practica1.LinkedQ;
//
//import java.util.Iterator;
//import util.Queue;
//
//public class LinkedQueue<E> implements Queue<E> {
//
//  //Completar
//
//  @Override
//  public int size() {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public int free() {
//    throw new UnsupportedOperationException();
//  }
//
//  @Override
//  public boolean empty() {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public boolean full() {
//    return false;
//  }
//
//  @Override
//  public E peekFirst() {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public E get() {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public void put(E e) {
//    throw new RuntimeException("//Completar...");
//  }
//
//
//  @Override
//  public String toString() {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public Iterator<E> iterator() {
//    return new MyIterator();
//  }
//
//  class MyIterator implements Iterator {
//
//    //Completar...
//
//    @Override
//    public boolean hasNext() {
//      throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public E next() {
//      throw new RuntimeException("//Completar...");
//    }
//
//    @Override
//    public void remove() {
//      throw new RuntimeException("//Completar...");
//    }
//
//  }
//}
