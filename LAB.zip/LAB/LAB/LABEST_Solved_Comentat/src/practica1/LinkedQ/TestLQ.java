

package practica1.LinkedQ;

import java.util.Arrays;

public class TestLQ {
    public TestLQ() {
    }

    public static void main(String[] args) {
        LinkedQueue<Integer> q = new LinkedQueue();
        Integer[] v = new Integer[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        System.out.println("Array content: " + Arrays.toString(v));

        for(int i = 0; i < v.length; ++i) {
            q.put(v[i]);
        }

        System.out.println("Queue content: " + q);
        System.out.print("Now, we empty the queue taking: ");

        while(!q.empty()) {
            System.out.print(q.get() + ", ");
        }

        System.out.println("\nqueue content: " + q);
    }
}

//package practica1.LinkedQ;
//
//import java.util.Arrays;
//
//public class TestLQ {
//
//  public static void main(String[] args) {
//    LinkedQueue<Integer> q = new LinkedQueue<>();
//    throw new RuntimeException("//Completar...");
//  }
//}
