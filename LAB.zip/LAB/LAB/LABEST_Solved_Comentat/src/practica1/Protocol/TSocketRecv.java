package practica1.Protocol;

import util.SimNet;
import util.TCPSegment;
import util.TSocket_base;

public class TSocketRecv extends TSocket_base {
    public TSocketRecv(SimNet net) {
        super(net);
    }

    public int receiveData(byte[] data, int offset, int length) {
        TCPSegment s = this.network.receive();
        this.printRcvSeg(s);
        int a_agafar = Math.min(s.getDataLength(), length);
        if (a_agafar < s.getDataLength()) {
            this.log.printRED("\t\t\t\t\t\t\tDiscarded data from segment!!!");
        }

        System.arraycopy(s.getData(), 0, data, offset, a_agafar);
        return a_agafar;
    }
}

//package practica1.Protocol;
//
//import util.TCPSegment;
//import util.TSocket_base;
//import util.SimNet;
//
//public class TSocketRecv extends TSocket_base {
//
//  public TSocketRecv(SimNet net) {
//    super(net);
//  }
//
//  @Override
//  public int receiveData(byte[] data, int offset, int length) {
//    throw new RuntimeException("//Completar...");
//  }
//}
