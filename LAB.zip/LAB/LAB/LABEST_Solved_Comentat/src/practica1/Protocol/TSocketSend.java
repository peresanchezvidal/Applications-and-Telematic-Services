
package practica1.Protocol;

import util.SimNet;
import util.TCPSegment;
import util.TSocket_base;

public class TSocketSend extends TSocket_base {
    public TSocketSend(SimNet net) {
        super(net);
    }

    @Override
    public void sendData(byte[] data, int offset, int length) {
        TCPSegment s = new TCPSegment();
        s.setPsh(true);
        s.setData(data, offset, length);
        System.out.println("snd --> " + s);
        this.network.send(s);
    }
}

//package practica1.Protocol;
//
//import util.TCPSegment;
//import util.TSocket_base;
//import util.SimNet;
//
//public class TSocketSend extends TSocket_base {
//
//  public TSocketSend(SimNet net) {
//    super(net);
//  }
//
//  @Override
//  public void sendData(byte[] data, int offset, int length) {
//    throw new RuntimeException("//Completar...");
//  }
//}
