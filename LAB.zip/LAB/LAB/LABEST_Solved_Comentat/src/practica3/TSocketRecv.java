package practica3;

import practica1.CircularQ.CircularQueue;
import util.SimNet;
import util.TCPSegment;
import util.TSocket_base;

public class TSocketRecv extends TSocket_base {
    protected Thread thread;
    protected CircularQueue<TCPSegment> rcvQueue = new CircularQueue(50);
    protected int rcvSegConsumedBytes = 0;

    public TSocketRecv(SimNet net) {
        super(net);
        (new ReceiverTask()).start();
    }

    public int receiveData(byte[] buf, int offset, int length) {
        this.lock.lock();

        try {
            while(this.rcvQueue.empty()) {
                this.appCV.awaitUninterruptibly();
            }

            int agafats;
            for(agafats = 0; length > agafats && !this.rcvQueue.empty(); agafats += this.consumeSegment(buf, offset + agafats, length - agafats)) {
            }

            int var5 = agafats;
            return var5;
        } finally {
            this.lock.unlock();
        }
    }

    protected int consumeSegment(byte[] buf, int offset, int length) {
        TCPSegment seg = (TCPSegment)this.rcvQueue.peekFirst();
        int a_agafar = Math.min(length, seg.getDataLength() - this.rcvSegConsumedBytes);
        System.arraycopy(seg.getData(), this.rcvSegConsumedBytes, buf, offset, a_agafar);
        this.rcvSegConsumedBytes += a_agafar;
        if (this.rcvSegConsumedBytes == seg.getDataLength()) {
            this.rcvQueue.get();
            this.rcvSegConsumedBytes = 0;
        }

        return a_agafar;
    }

    public void processReceivedSegment(TCPSegment rseg) {
        this.lock.lock();

        try {
            this.printRcvSeg(rseg);
            if (!rseg.isPsh()) {
                return;
            }

            if (!this.rcvQueue.full()) {
                this.rcvQueue.put(rseg);
                this.appCV.signalAll();
                return;
            }

            this.log.printRED("\t\t\t\t\t\t\t\tQueue full, discarded segment!!!");
        } finally {
            this.lock.unlock();
        }

    }

    class ReceiverTask extends Thread {
        ReceiverTask() {
        }

        public void run() {
            while(true) {
                TCPSegment rseg = TSocketRecv.this.network.receive();
                TSocketRecv.this.processReceivedSegment(rseg);
            }
        }
    }
}

//package practica3;
//
//import practica1.CircularQ.CircularQueue;
//import util.Const;
//import util.TCPSegment;
//import util.TSocket_base;
//import util.SimNet;
//
//public class TSocketRecv extends TSocket_base {
//
//  protected Thread thread;
//  protected CircularQueue<TCPSegment> rcvQueue;
//  protected int rcvSegConsumedBytes;
//
//  public TSocketRecv(SimNet net) {
//    super(net);
//    rcvQueue = new CircularQueue<>(Const.RCV_QUEUE_SIZE);
//    rcvSegConsumedBytes = 0;
//    new ReceiverTask().start();
//  }
//
//  @Override
//  public int receiveData(byte[] buf, int offset, int length) {
//    lock.lock();
//    try {
//      throw new RuntimeException("//Completar...");
//    } finally {
//      lock.unlock();
//    }
//  }
//
//  protected int consumeSegment(byte[] buf, int offset, int length) {
//    TCPSegment seg = rcvQueue.peekFirst();
//    int a_agafar = Math.min(length, seg.getDataLength() - rcvSegConsumedBytes);
//    System.arraycopy(seg.getData(), rcvSegConsumedBytes, buf, offset, a_agafar);
//    rcvSegConsumedBytes += a_agafar;
//    if (rcvSegConsumedBytes == seg.getDataLength()) {
//      rcvQueue.get();
//      rcvSegConsumedBytes = 0;
//    }
//    return a_agafar;
//  }
//
//  @Override
//  public void processReceivedSegment(TCPSegment rseg) {  
//    lock.lock();
//    try {
//      throw new RuntimeException("//Completar...");
//    } finally {
//      lock.unlock();
//    }
//  }
//
//  class ReceiverTask extends Thread {
//
//    @Override
//    public void run() {
//      while (true) {
//        TCPSegment rseg = network.receive();
//        processReceivedSegment(rseg);
//      }
//    }
//  }
//}
