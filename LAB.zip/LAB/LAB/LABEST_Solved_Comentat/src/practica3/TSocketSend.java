package practica3;

import util.SimNet;
import util.TCPSegment;
import util.TSocket_base;

public class TSocketSend extends TSocket_base {
    protected int MSS;

    public TSocketSend(SimNet net) {
        super(net);
        this.MSS = net.getMTU() - 20 - 20;
    }

    public void sendData(byte[] data, int offset, int length) {
        int a_enviar;
        for(int enviat = 0; length > enviat; enviat += a_enviar) {
            a_enviar = Math.min(length - enviat, this.MSS);
            TCPSegment seg = this.segmentize(data, offset + enviat, a_enviar);
            System.out.println("snd --> " + seg);
            this.network.send(seg);
        }

    }

    protected TCPSegment segmentize(byte[] data, int offset, int length) {
        TCPSegment seg = new TCPSegment();
        seg.setPsh(true);
        seg.setData(data, offset, length);
        return seg;
    }
}

//package practica3;
//
//import util.Const;
//import util.TCPSegment;
//import util.TSocket_base;
//import util.SimNet;
//
//public class TSocketSend extends TSocket_base {
//
//  protected int MSS;       // Maximum Segment Size
//
//  public TSocketSend(SimNet net) {
//    super(net);
//    MSS = net.getMTU() - Const.IP_HEADER - Const.TCP_HEADER;
//  }
//
//  @Override
//  public void sendData(byte[] data, int offset, int length) {
//    throw new RuntimeException("//Completar...");
//  }
//
//  protected TCPSegment segmentize(byte[] data, int offset, int length) {
//    throw new RuntimeException("//Completar...");
//  }
//
//}
