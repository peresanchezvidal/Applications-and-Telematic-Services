
package practica3;

import java.util.Random;
import practica2.Protocol.SimNet_Monitor;
import util.Const;
import util.Log;
import util.TCPSegment;

public class SimNet_Loss extends SimNet_Monitor {
    private double lossRate;
    private Random rand;
    private Log log;

    public SimNet_Loss(double lossRate) {
        this.lossRate = lossRate;
        this.rand = new Random(1L);
        this.log = Log.getLog();
    }

    @Override
    public void send(TCPSegment seg) {
        if (this.rand.nextDouble() < this.lossRate) {
            this.log.printRED("\t\t +++++++++ SEGMENT LOST: " + seg + " +++++++++\n");
        } else {
            super.send(seg);
        }
    }

    @Override
    public int getMTU() {
      return Const.MTU_ETHERNET;
    }
}

//package practica3;
//
//import java.util.Random;
//import util.Const;
//import util.Log;
//import util.TCPSegment;
//
//public class SimNet_Loss extends practica2.Protocol.SimNet_Monitor {
//
//  private double lossRate;
//  private Random rand;
//  private Log log;
//
//  public SimNet_Loss(double lossRate) {
//    this.lossRate = lossRate;
//    rand = new Random(Const.SEED);
//    log = Log.getLog();
//  }
//
//  @Override
//  public void send(TCPSegment seg) {
//    throw new RuntimeException("//Completar...");
//  }
//
//  @Override
//  public int getMTU() {
//    throw new RuntimeException("//Completar...");
//  }
//}
