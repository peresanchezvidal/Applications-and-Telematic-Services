package practica7;

import util.Const;
import practica1.CircularQ.CircularQueue;
import util.TCPSegment;
import util.TSocket_base;

// * Connection oriented Protocol Control Block.
// *
// * Each instance of TSocket maintains all the status of an endpoint.
// * 
// * Interface for application layer defines methods for passive/active opening and for closing the connection.
// * Interface lower layer defines methods for processing of received segments and for sending of segments.
// * We assume an ideal lower layer with no losses and no errors in packets.
// *
// * State diagram:<pre>
//                              +---------+
//                              |  CLOSED |-------------
//                              +---------+             \
//                           LISTEN  |                   \
//                           ------  |                    | CONNECT
//                                   V                    | -------
//                              +---------+               | snd SYN
//                              |  LISTEN |               |
//                              +---------+          +----------+
//                                   |               | SYN_SENT |
//                                   |               +----------+
//                         rcv SYN   |                    |
//                         -------   |                    | rcv SYN
//                         snd SYN   |                    | -------
//                                   |                    |
//                                   V                   /
//                              +---------+             /
//                              |  ESTAB  |<------------
//                              +---------+
//                       CLOSE    |     |    rcv FIN
//                      -------   |     |    -------
// +---------+          snd FIN  /       \                    +---------+
// |  FIN    |<-----------------           ------------------>|  CLOSE  |
// |  WAIT   |------------------           -------------------|  WAIT   |
// +---------+          rcv FIN  \       /   CLOSE            +---------+
//                      -------   |      |  -------
//                                |      |  snd FIN 
//                                V      V
//                              +----------+
//                              |  CLOSED  |
//                              +----------+
// * </pre>
// *
// * @author AST's teachers
// */
public class TServerSocket extends TSocket_base {

    /**
     * Protocol del TServerSocket.
     */
    protected Protocol proto;

    /**
     * Estat en el que ens trobem.
     */
    protected int state;

    /**
     *
     */
    protected CircularQueue<TSocket> acceptQueue;

    /**
     * Estats de la FSM.
     */
    protected static final int CLOSED = 0,
                               LISTEN = 1,
                               SYN_SENT = 2,
                               ESTABLISHED = 3,
                               FIN_WAIT = 4,
                               CLOSE_WAIT = 5;

    /**
     * Mètode constructor.
     *
     * @param p protocol del socket
     * @param localPort local port del socket
     */
    protected TServerSocket(Protocol p, int localPort) {
        super(p.getNetwork());
        proto = p;
        this.localPort = localPort;
        //En situem a l'estat 0
        state = CLOSED;
        //Afegim el socket a la llista de ListenSocket del protocol
        p.addListenTSocket(this);
        //Invoquem el mètode listen();
        listen();
    }

    /**
     * Mètode que incialitza una cua circular de dimensió 10. Canvia l'estat al
     * 1 (LISTEN) i s'afegeix a la llista de ListenSockets.
     */
    @Override
    public void listen() {
        lock.lock();
        try {
            acceptQueue = new CircularQueue<>(Const.LISTEN_QUEUE_SIZE);
            state = LISTEN;
            proto.addListenTSocket(this);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Un cop s'invoca accept, si la cua té algun element, es retorna le primer i s'extreu de la cua. 
     * @return primer socket de la cua d'accpetats al server
     */
    @Override
    public TSocket accept() {
        this.lock.lock();

        TSocket sc;
        try {
            while (this.acceptQueue.empty()) {
                this.appCV.awaitUninterruptibly();
            }

            sc = (TSocket) this.acceptQueue.get();
        } finally {
            this.lock.unlock();
        }

        return sc;
    }

    /**
     * Mètode que processa le segment rebut
     * @param rseg 
     */
    @Override
    public void processReceivedSegment(TCPSegment rseg) {
        this.lock.lock();

        try {
            //S'imprimeix que s'ha rebut un segment
            this.printRcvSeg(rseg);
            //Depenen de l'estat en el que ens trobem
            switch (this.state) {
                //Si esten en LISTEN
                case LISTEN:
                    //Si és de tipus Syn i la cua de sockets del server no està plena
                    if (rseg.isSyn() && !this.acceptQueue.full()) {
                        //Creem un nou socket amb els local i remote ports del seegment (invertits) de manera que sigui el dest. I amb e mateix protocol que l'actual
                        TSocket new_sc = new TSocket(this.proto, this.localPort, rseg.getSourcePort());
                        //Posem el socket nou a l'estat 3 --> ESTABLISHED
                        new_sc.state = 3;
                        // S'afegeux aquest nou socket a la llista de Socket actius
                        this.proto.addActiveTSocket(new_sc);
                        //S'afegeix el socket a la cua del server on estan els acpetats
                        this.acceptQueue.put(new_sc);
                        //Es desperta a possibles que estan esperant qu ehi hagi algun socket a la cua d'acceptats
                        this.appCV.signal();
                        //Es crea un nou TCP segment
                        TCPSegment seg = new TCPSegment();
                        // de tpus syn
                        seg.setSyn(true);
                        //Amb local i dest port invertits als del socket que hem creat, per tant iguals al segment que hem de processar
                        seg.setSourcePort(new_sc.localPort);
                        seg.setDestinationPort(new_sc.remotePort);
                        //Imprimim que el volem enviar
                        this.printSndSeg(seg);
                        //l'enviem
                        new_sc.network.send(seg);
                    }
            }
        } finally {
            this.lock.unlock();
        }

    }

    /**
     * Mètode per imprimir fàcilment la informació del segment que hem rebut.
     * @param rseg segment d'on treiem les dades
     */
    protected void printRcvSeg(TCPSegment rseg) {
        this.log.printBLACK("\t\t\t\t\t\t\t    rcvd: " + rseg);
    }

    /**
     * Mètode per imprimir fàcilment la informació del segment que hem enviat.
     * @param rseg segment d'on treiem les dades
     */
    protected void printSndSeg(TCPSegment rseg) {
        this.log.printBLACK("\t\t\t\t\t\t\t    sent: " + rseg);
    }
}