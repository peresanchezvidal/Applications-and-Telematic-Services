package practica7;

import practica1.CircularQ.CircularQueue;
import util.TCPSegment;
import util.TSocket_base;
import util.Const;

///**
// * Connection oriented Protocol Control Block.
// *
// * Each instance of TSocket maintains all the status of an endpoint.
// * 
// * Interface for application layer defines methods for passive/active opening and for closing the connection.
// * Interface lower layer defines methods for processing of received segments and for sending of segments.
// * We assume an ideal lower layer with no losses and no errors in packets.
// *
// * State diagram:<pre>
//                              +---------+
//                              |  CLOSED |-------------
//                              +---------+             \
//                           LISTEN  |                   \
//                           ------  |                    | CONNECT
//                                   V                    | -------
//                              +---------+               | snd SYN
//                              |  LISTEN |               |
//                              +---------+          +----------+
//                                   |               | SYN_SENT |
//                                   |               +----------+
//                         rcv SYN   |                    |
//                         -------   |                    | rcv SYN
//                         snd SYN   |                    | -------
//                                   |                    |
//                                   V                   /
//                              +---------+             /
//                              |  ESTAB  |<------------
//                              +---------+
//                       CLOSE    |     |    rcv FIN
//                      -------   |     |    -------
// +---------+          snd FIN  /       \                    +---------+
// |  FIN    |<-----------------           ------------------>|  CLOSE  |
// |  WAIT   |------------------           -------------------|  WAIT   |
// +---------+          rcv FIN  \       /   CLOSE            +---------+
//                      -------   |      |  -------
//                                |      |  snd FIN 
//                                V      V
//                              +----------+
//                              |  CLOSED  |
//                              +----------+
// * </pre>
// *
// * @author AST's teachers
// */
public class TSocket extends TSocket_base {

    /**
     * Protocol del Socket.
     */
    protected Protocol proto;

    /**
     * Estat en el qual es troba el Socket.
     */
    protected int state;

    /**
     * Cua dels sockets acceptats.
     */
    protected CircularQueue<TSocket> acceptQueue;

    /**
     * Estats amb noms.
     */
    protected static final int CLOSED = 0,
            LISTEN = 1,
            SYN_SENT = 2,
            ESTABLISHED = 3,
            FIN_WAIT = 4,
            CLOSE_WAIT = 5;

    /**
     * Construcor del socket.
     *
     * @param p protocol que ha de tenir (aquest ja té una xarxa asignada
     * @param localPort port local del socket
     * @param remotePort port remot del socket
     */
    protected TSocket(Protocol p, int localPort, int remotePort) {
        super(p.getNetwork());
        proto = p;
        this.localPort = localPort;
        this.remotePort = remotePort;
        //comença en closed
        state = CLOSED;
        //Un cop es crea, s'affegeix a la llista de protocols com a socket actiu
        p.addActiveTSocket(this);
    }

    /**
     * Mètode conect on s'envia un segment tipus syn.
     */
    @Override
    public void connect() {
        lock.lock();
        try {
            //Es canvia d'estat
            this.state = SYN_SENT;
            //S'afegeix com a socket actiu
            this.proto.addActiveTSocket(this);
            /*Es crea un segment de tipus syn amb local port el socket en el que ens torbem
            i destí el que té apuntat el nostre socket. Enviem el segment i ho imrimim per pantalla.
             */
            TCPSegment seg = new TCPSegment();
            seg.setSyn(true);
            seg.setSourcePort(this.localPort);
            seg.setDestinationPort(this.remotePort);
            this.printSndSeg(seg);
            this.network.send(seg);

            /*Sempre i quan l'estat no sigui ESTABLISHED s'ha d'esperar, doncs encara no ha establert
            conexió amb cap Socket. */
            while (this.state != ESTABLISHED) {
                this.appCV.awaitUninterruptibly();
            }
        } finally {
            this.lock.unlock();
        }

    }

    /**
     * Quan executem un close per tant, quan hem enviat un segment tipus fin.
     */
    public void close() {
        this.lock.lock();

        try {
            //Depèn de l'estat fem una cosa, o una altra.
            switch (this.state) {
                case ESTABLISHED:
                /*
                Si està en estat ESTABLISHED pasarà a executar el que es demana en el estat de CLOSE_WAIT (!!!No hi ha break) 
                Per tant, passa al estat FIN_WAIT. Crea un nou segment de tipus fin amb els local i remot ports del socket i l'envia. 
                 */
                case CLOSE_WAIT:
                    /*
                    Si esta en CLOSE_WAIT pasarà a l'estat close, borrem el socket de la llista de sockets actius que es troba
                    a protocol.Crea un nou segment de tipus fin amb els local i remot ports del socket i l'envia. 
                    */
                    if (this.state == ESTABLISHED) {
                        this.state = FIN_WAIT;
                    } else {
                        this.state = CLOSED;
                        this.proto.removeActiveTSocket(this);
                    }

                    TCPSegment seg = new TCPSegment();
                    seg.setFin(true);
                    seg.setSourcePort(this.localPort);
                    seg.setDestinationPort(this.remotePort);
                    this.printSndSeg(seg);
                    this.network.send(seg);
            }
        } finally {
            this.lock.unlock();
        }

    }

    /**
     * Aquest mètode explica que farà un Socket quan rep un segment. 
     * @param rseg segment a processar
     */
    public void processReceivedSegment(TCPSegment rseg) {
        this.lock.lock();

        try {
            //Imprimeix el segment rebut
            this.printRcvSeg(rseg);
            switch (this.state) {
                case SYN_SENT:
                    /*
                    Si es troba en SYN_SENT i el segment rebut es syn, es passa a estat ESTABLISHED i es desperta al socket
                    el qual estava esperant a tenir conexió.
                    */
                    if (rseg.isSyn()) {
                        this.state = ESTABLISHED;
                        this.appCV.signal();
                    }
                    break;
                case ESTABLISHED:
                    /*
                    Si es troba en estat ESTABLISHED:
                    - si el segment és de tipus PSH s'haurien de processar les dades del segment.
                    - si és de tipus FIN es pasa a estat CLOSE_WAIT
                    */
                case FIN_WAIT:
                    /*
                    Si es troba en estat FIN_WAIT 
                    - Si el segment es de tipus PSH s'haurien de processar les dades del segment. 
                    - Si és de tipus FIN cal passar a estat CLOSED i es borra el socket en 
                      el que estem de la llista de Sockets actius. 
                    */
                case CLOSE_WAIT:
                    /*
                    Si ens trobem a CLOSE_WAIT, no hauriem de rebre ja res més perquè l'altre 
                    banda està tancada per tant, ignorem el segment.
                    */
                    if (rseg.isPsh()) {
                        if (state == ESTABLISHED || state == FIN_WAIT) {
                            // Here should go the segment's data processing.
                        } else {// This should not occur, since a FIN has been 
                            // received from the remote side. 
                            // Ignore the data segment.
                        }
                    }

                    if (rseg.isFin()) {
                        if (this.state == ESTABLISHED) {
                            this.state = CLOSE_WAIT;
                        } else if (this.state == FIN_WAIT) {
                            this.state = CLOSED;
                            this.proto.removeActiveTSocket(this);
                        }
                    }
            }
        } finally {
            this.lock.unlock();
        }

    }

    /**
     * Mètode per imprimir fàcilment la informació del segment que hem rebut.
     * @param rseg segment d'on treiem les dades
     */
    protected void printRcvSeg(TCPSegment rseg) {
        this.log.printBLACK("    rcvd: " + rseg);
    }

    /**
     * Mètode per imprimir fàcilment la informació del segment que hem enviat.
     * @param rseg segment d'on treiem les dades
     */
    protected void printSndSeg(TCPSegment rseg) {
        this.log.printBLACK("    sent: " + rseg);
    }
}
