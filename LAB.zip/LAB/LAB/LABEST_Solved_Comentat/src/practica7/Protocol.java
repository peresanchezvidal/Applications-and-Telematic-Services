package practica7;

import java.util.Iterator;
import util.Protocol_base;
import util.SimNet;
import util.TCPSegment;
import util.TSocket_base;


public class Protocol extends Protocol_base {
    /**
     * Constructor d'un protocol. A part de la network s'inicialitzen també els locks, active o no
     * sockets, thread i log. 
     * @param net Xarxa que emprarem
     */
    protected Protocol(SimNet net) {
        super(net);
    }

    /**
     * Mètode que busca el socket necessari per establir conexió. 
     * @param segment Segment que volem enviar
     */
    public void ipInput(TCPSegment segment) {
        //Creem un socket "general" que sigui el corresponent segons les dades del segment
        TSocket_base sc = this.getMatchingTSocket(segment.getDestinationPort(), segment.getSourcePort());
        //Si no s'ha trobat un socket,el processem
        if (sc != null) {
            sc.processReceivedSegment(segment);
        } else {
            //Sinó, imprimim que no hem torbat el socket que buscàvem.
            this.log.printRED("\t\t\tno matching socket for seg: " + segment);
        }

    }

    /**
     * Mètode que permet buscar un socket a la llista de actives sockets. 
     * @param localPort local port que té el socket que busquem
     * @param remotePort remote port que té el socket que bsuquem
     * @return retorna el socket en cas que l'haguem trobar, en cas contrari, retorna null
     */
    protected TSocket_base getMatchingTSocket(int localPort, int remotePort) {
        this.lk.lock();

        // incialitzem un socket general
        TSocket_base var5;
        try {
            //fem un iterador de la llista dels socket actius
            Iterator var3 = this.activeSockets.iterator();

            //Creem una variable auxiliar de tipus socket per tal se analitzar si és el que estem buscant. 
            TSocket_base sc;
            //Analitza el següent sempre i quan el local o el remote port sigui diferent al que busquem 
            do {
                //SI NO té més sockets a la llista
                if (!var3.hasNext()) {
                    //Canviem l'iterador a la llista de listenSockets
                    var3 = this.listenSockets.iterator();
                    
                    //Sempre i quan el local port sigui diferent al que cerquem
                    do {
                        //Si ja hem recorregut tota la llista
                        if (!var3.hasNext()) {
                            //tornem null
                            return null;
                        }
                        //Sinó mirem el següent
                        sc = (TSocket_base)var3.next();
                    } while(sc.localPort != localPort);
                    //En el cal que el local port sigui igual al que busquem l'igualem i el retornem
                    var5 = sc;
                    return var5;
                }
                //Igualem el sc al que ens toca i passem el següent
                sc = (TSocket_base)var3.next();
            } while(sc.localPort != localPort || sc.remotePort != remotePort);
            //Si ja hem trobat els ports que matchean, sortim i el retornem
            var5 = sc;
        } finally {
            this.lk.unlock();
        }

        return var5;
    }
}