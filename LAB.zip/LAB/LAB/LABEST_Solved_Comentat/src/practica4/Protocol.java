//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package practica4;

import java.util.Iterator;
import util.Protocol_base;
import util.SimNet;
import util.TCPSegment;
import util.TSocket_base;

public class Protocol extends Protocol_base {
    public Protocol(SimNet net) {
        super(net);
    }

    protected void ipInput(TCPSegment seg) {
        TSocket_base sock = this.getMatchingTSocket(seg.getDestinationPort(), seg.getSourcePort());
        if (sock != null) {
            sock.processReceivedSegment(seg);
        } else {
            this.log.printRED("\t\t\tno matching socket for seg: " + seg);
        }

    }

    protected TSocket_base getMatchingTSocket(int localPort, int remotePort) {
        this.lk.lock();

        try {
            Iterator var3 = this.activeSockets.iterator();

            while(var3.hasNext()) {
                TSocket_base sc = (TSocket_base)var3.next();
                if (sc.localPort == localPort && sc.remotePort == remotePort) {
                    TSocket_base var5 = sc;
                    return var5;
                }
            }
        } finally {
            this.lk.unlock();
        }

        return null;
    }
}

//package practica4;
//
//import util.Protocol_base;
//import util.TCPSegment;
//import util.SimNet;
//import util.TSocket_base;
//
//public class Protocol extends Protocol_base {
//
//    public Protocol(SimNet net) {
//      super(net);
//    }
//
//    protected void ipInput(TCPSegment seg) {
//        throw new RuntimeException("//Completar...");
//    }
//
//    protected TSocket_base getMatchingTSocket(int localPort, int remotePort) {
//        lk.lock();
//        try {
//            throw new RuntimeException("//Completar...");
//        } finally {
//            lk.unlock();
//        }
//    }
//}
