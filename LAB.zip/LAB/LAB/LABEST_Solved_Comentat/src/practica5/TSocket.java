package practica5;

import practica1.CircularQ.CircularQueue;
import practica4.Protocol;
import util.Const;
import util.TCPSegment;
import util.TSocket_base;

public class TSocket extends TSocket_base {
    // Sender variables:
    protected int MSS;
    protected int snd_sndNxt;
    protected int snd_rcvWnd;
    protected int snd_rcvNxt;
    protected TCPSegment snd_UnacknowledgedSeg;
    protected boolean zero_wnd_probe_ON;
    
    // Receiver variables:
    protected CircularQueue<TCPSegment> rcv_Queue;
    protected int rcv_SegConsumedBytes;
    protected int rcv_rcvNxt;

    protected TSocket(Protocol p, int localPort, int remotePort) {
        super(p.getNetwork());
        this.localPort = localPort;
        this.remotePort = remotePort;
        p.addActiveTSocket(this);
        // init sender variables
        MSS = p.getNetwork().getMTU() - Const.IP_HEADER - Const.TCP_HEADER;
        // init receiver variables
        rcv_Queue = new CircularQueue<>(Const.RCV_QUEUE_SIZE);
        snd_rcvWnd = Const.RCV_QUEUE_SIZE;
    }

    @Override
    public void sendData(byte[] data, int offset, int length) {
        this.lock.lock();

        try {
            int enviats = 0;

            while(length > enviats){
                while(this.snd_sndNxt - this.snd_rcvNxt == 1 && this.snd_rcvWnd > 0 || this.zero_wnd_probe_ON) {
                    this.appCV.awaitUninterruptibly();
                }

                if (this.snd_rcvWnd > 0) {
                    int a_posar = Math.min(length - enviats, this.MSS);
                    this.snd_UnacknowledgedSeg = this.segmentize(data, offset + enviats, a_posar);
                    this.network.send(this.snd_UnacknowledgedSeg);
                    this.startRTO(this.snd_UnacknowledgedSeg);
                    ++this.snd_sndNxt;
                    enviats += a_posar;
                } else {
                    this.snd_UnacknowledgedSeg = this.segmentize(data, offset + enviats, 1);
                    this.network.send(this.snd_UnacknowledgedSeg);
                    this.startRTO(this.snd_UnacknowledgedSeg);
                    ++this.snd_sndNxt;
                    ++enviats;
                    this.zero_wnd_probe_ON = true;
                    this.log.printPURPLE("----- zero-window probe ON -----");
                }
            }
        } finally {
            this.lock.unlock();
        }

    }

    protected TCPSegment segmentize(byte[] data, int offset, int length) {
        TCPSegment seg = new TCPSegment();
        seg.setPsh(true);
        seg.setSourcePort(this.localPort);
        seg.setDestinationPort(this.remotePort);
        seg.setSeqNum(this.snd_sndNxt);
        seg.setData(data, offset, length);
        return seg;
    }

    @Override
    protected void timeout(TCPSegment seg) {
        this.lock.lock();
        
        try {
            if (this.snd_UnacknowledgedSeg != null) {
                if (this.zero_wnd_probe_ON) {
                    this.log.printPURPLE("0-wnd probe: " + this.snd_UnacknowledgedSeg);
                } else {
                    this.log.printPURPLE("retrans: " + this.snd_UnacknowledgedSeg);
                }

                this.network.send(this.snd_UnacknowledgedSeg);
                this.startRTO(this.snd_UnacknowledgedSeg);
            }
        } finally {
            this.lock.unlock();
        }
    }

    @Override
    public int receiveData(byte[] buf, int offset, int maxlen) {
        this.lock.lock();
        
        try {
            while(this.rcv_Queue.empty()) {
                this.appCV.awaitUninterruptibly();
            }

            int agafats;
            for(agafats = 0; maxlen > agafats && !this.rcv_Queue.empty(); agafats += this.consumeSegment(buf, offset + agafats, maxlen - agafats)) {
            }

            int var5 = agafats;
            return var5;
        } finally {
            this.lock.unlock();
        }
    }

    protected int consumeSegment(byte[] buf, int offset, int length) {
        TCPSegment seg = (TCPSegment)this.rcv_Queue.peekFirst();
        int a_agafar = Math.min(length, seg.getDataLength() - this.rcv_SegConsumedBytes);
        System.arraycopy(seg.getData(), this.rcv_SegConsumedBytes, buf, offset, a_agafar);
        this.rcv_SegConsumedBytes += a_agafar;
        if (this.rcv_SegConsumedBytes == seg.getDataLength()) {
            this.rcv_Queue.get();
            this.rcv_SegConsumedBytes = 0;
        }
        
        return a_agafar;
    }

    protected void sendAck() {
        TCPSegment ack = new TCPSegment();
        ack.setAck(true);
        ack.setSourcePort(this.localPort);
        ack.setDestinationPort(this.remotePort);
        ack.setAckNum(this.rcv_rcvNxt);
        ack.setWnd(this.rcv_Queue.free());
        this.network.send(ack);
    }

    @Override
    public void processReceivedSegment(TCPSegment rseg) {
        this.lock.lock();

        try {
            this.printRcvSeg(rseg);
            if (rseg.isAck() && rseg.getAckNum() == this.snd_sndNxt) {
                this.snd_UnacknowledgedSeg = null;
                if (this.zero_wnd_probe_ON) {
                    this.zero_wnd_probe_ON = false;
                    this.log.printPURPLE("----- zero-window probe OFF -----");
                }

                this.snd_UnacknowledgedSeg = null;
                this.snd_rcvNxt = rseg.getAckNum();
                this.snd_rcvWnd = rseg.getWnd();
                this.appCV.signal();
            } else if (rseg.isPsh() && !this.rcv_Queue.full()) {
                if (rseg.getSeqNum() == this.rcv_rcvNxt) {
                    this.rcv_Queue.put(rseg);
                    ++this.rcv_rcvNxt;
                    this.appCV.signal();
                }

                this.sendAck();
            }
        } finally {
            this.lock.unlock();
        }

    }
}