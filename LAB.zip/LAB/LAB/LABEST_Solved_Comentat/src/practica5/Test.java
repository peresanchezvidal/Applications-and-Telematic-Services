package practica5;

import util.SimNet_FullDuplex;
import practica4.Protocol;
import util.Const;
import util.Receiver;
import util.Sender;
import util.SimNet;

public class Test {

    public static void main(String[] args) {

        //Creem una xarxa que crea dos SimNet_Loss, una de cada loss rate de les que passem 
        SimNet_FullDuplex net = new SimNet_FullDuplex(Const.LOSS_RATE_PSH, Const.LOSS_RATE_ACK);

        new Thread(new HostSnd(net.getSndEnd())).start();
        new Thread(new HostRcv(net.getRcvEnd())).start();
    }
}

class HostSnd implements Runnable {

    //Port local del sender
    public static final int PORT = 10;
    //protocolo
    protected Protocol proto;

    public HostSnd(SimNet net) {
        this.proto = new Protocol(net);
    }

    public void run() {
        //A part del socket, Const.SND_NUM és el número de segments que vols enviar, Const.SND_SIZE mida del buffer de cada segment, Const.SND_INTERVAL cada quan s'envia un segment.
        new Sender(new TSocket(proto, HostSnd.PORT, HostRcv.PORT)).start();
    }
}

class HostRcv implements Runnable {
    //Port local del Rcv
    public static final int PORT = 80;

    protected Protocol proto;

    public HostRcv(SimNet net) {
        this.proto = new Protocol(net);
    }

    public void run() {
        //A part de que el Socket del receiver té RCV_SIZE com a mida del buffer i RCV_INTERVAL com a interval de temps que passa entre un cop i l'altre.
        new Receiver(new TSocket(proto, HostRcv.PORT, HostSnd.PORT)).start();
    }
}
